---
name: retention-mechanics
description: Why viewers keep watching and how a script holds them: the first seconds, the line after the hook, the progression test, short-range rehooks between segments, list ordering, pacing guides and the retention mistakes to avoid. Use when planning or writing any script, and when a retention graph shows viewers leaving. Base rule file: applies to every channel unless a niche pack or persona profile explicitly overrides a specific rule.
---

# Retention mechanics

**How this file relates to niche packs.** This is a base rule file. A niche pack or persona profile overrides it only where that file explicitly says so; everywhere else, it applies.

**Retention and voice are separate problems.** A script can pass every check here and still sound like AI, because this file covers why people keep watching, not whether the lines sound spoken. Voice is handled in `voice-anchoring.md` and `humanizer.md`.

---

## 1. The viewer's path through a video

1. **A question forms.** Early on, the viewer has a question they care about: will this fix my drain, could I sell this, why does my hen stop laying? The closer the question is to their own life, the stronger the pull.
2. **Each answer lands.** Every question the script raises gets answered fully, and the answer is useful, not obvious. A question left hanging feels like a cheat.
3. **Trust builds.** With no face on screen, trust comes from competence: clear steps, real numbers, honest limits, and more value than promised.
4. **They leave with something to do.** The video ends on a practical next action ("check the flapper tonight," "cut one board this weekend"). Never promise specific future videos.

---

## 2. The first seconds

- **Say what the video is about within about 10 seconds, using "you" or "your."** Viewers decide fast whether this is what they came for, and any delay makes them doubt it.
- **Open on what the thumbnail and title promised.** The first visual matches the thumbnail, and the first line names the title's subject. The video is built from the script, so that first line has to name what should be on screen; the visuals can only show what the narration mentions.
- **No greeting and no channel intro by default.** No "hey guys," no "today we're going to," no wind-up. Some niches suit a warm greeting, so a niche pack or persona profile can allow one.

---

## 3. The line after the hook

The first sentence after the hook either **pays off** (delivers the first item, step or fact) or **escalates** (raises the stakes). It never sets up background. These openings stall a video at its most fragile moment:

```
"To understand why..."
"First, let's go back..."
"Before we get into that..."
"To see how we got here..."
```

Background is allowed later, right before the moment that needs it, and only after a payoff has landed.

---

## 4. The progression test

Every paragraph must do at least one of these:

1. **Add new information** the viewer didn't have.
2. **Move toward the goal:** the next step, the next item, closer to the result.
3. **Raise an obstacle:** a mistake, a catch, a cost.
4. **Change how the viewer feels:** relief, surprise, confidence, concern.

A paragraph that does none of them is padding. Cut it; don't polish it. This is the main test for whether a script's length is honest.

---

## 5. Show, then explain

Show the thing working before explaining why it works. Explaining every rule before letting someone play is how viewers get lost.

**Default guide:** about one part explanation to two parts doing, alternating. The content decides, though. A tricky step can need more explanation; an obvious one needs none.

---

## 6. Rehooks between segments

In list videos and in step-by-step progressions, where something visibly changes from rough to finished or broken to fixed, a short bridge between segments keeps people moving forward. These are allowed and encouraged.

**The rules:**
- **Short range only.** A rehook points at the very next segment, never at "the end of the video" or "a bonus later." Long-range teases are on the hard ban list in `humanizer.md`.
- **Honest.** The next segment has to actually deliver what the bridge promised. Mild exaggeration in tone is fine; promising something the segment doesn't contain isn't.
- **One line.** A bridge is one sentence, often half of one. Sometimes the best bridge is just starting the next item.
- **Varied.** Never reuse the same bridge shape twice in a row, and rotate across scripts (`variety-rotation.md`).

**Bridge moves:**
- **The stakes of the next item:** "That one saves you a service call. The next one saves you a water heater."
- **Where the progress stands:** "It's square now, but it's still rough enough to snag a sweater. Sanding's next."
- **Self-recognition:** "If your edges wave like this, the next row is the fix."
- **Cost or effort:** "This next one costs nothing and takes about a minute."
- **A grounded surprise:** "The next one sounds backwards, but it's how the old shops did it."

**Cut these: hype with nothing behind it.**

```
"But that's not even the craziest part..."
"And number seven will blow your mind."
"What happened next changed everything."
```

After a payoff, the viewer briefly thinks "I got what I came for." The next segment starting, or a one-line bridge, carries them past that moment. A gap does the opposite.

---

## 7. Connecting beats

In narrative parts (a story, an explanation of why something happens), connect beats with **but** or **therefore**, never **and then**. "It worked, *but* the glue line showed, *therefore* the finish had to change" pulls the viewer along. "It worked, and then we glued it, and then we finished it" doesn't.

Build steps and list items are allowed to be sequential, since that's their nature. The rule applies to the storytelling and the reasoning around them.

---

## 8. The four retention mistakes

1. **The slow start.** Greetings, intros or background before the viewer knows they're in the right place.
2. **The context dump.** Front-loading every explanation before any doing.
3. **The payoff with nothing after it.** A segment ends and nothing pulls toward the next one.
4. **The broken promise.** The title promised one thing and the video delivers something else, or the promised item never arrives. Whatever the hook promises maps one to one to what the body delivers.

---

## 9. Ordering list items

**Default:** second-best item first, best item somewhere in the middle, third-best item last.
- Leading with the best leaves nowhere to go but down.
- The best item in the middle peaks the video.
- A strong final item ends it well.

**Exceptions:**
- A ranked countdown saves number one for last, because the reveal is the point.
- Niche packs can override the order. For example, a pack may open on the item the thumbnail shows.

---

## 10. Pacing guides

These are defaults, not targets. The content always decides.

- **Something new** (a fact, a step, a number) every 15-30 seconds or so.
- **No stretch longer than about 90 seconds** without a payoff. At normal narration speed that's roughly 220 words.
- **About one part explanation to two parts doing** (section 5).

A step that needs longer to explain properly gets longer. One that can be said in a sentence gets a sentence. Never pad to reach a pace, and never rush a step to keep one.

---

## 11. Rhythm

Vary sentence length. A run of same-length sentences drones, however good each one is. Put each sentence on its own line: the right edge should look jagged, not straight. Short instructions and real lists are fine; the problem is monotony. See also `humanizer.md`, H17.

---

## 12. Retention killers

These overlap with `humanizer.md` (H12, H16, H18):

- **Repeated emphasis:** saying how important something is three ways instead of once.
- **Piled-up qualifiers:** "this might potentially be one possible way…"
- **Announcing the obvious:** "now I'm going to tell you about the next point." Just go to it.
- **Throat-clearing:** "so, basically, the thing is…" Start with the point.

---

## 13. The read-aloud test

Read the whole script out loud before it's done. Mark every stumble, every phrase nobody would say, and every spot where you'd naturally pause (those are the line breaks). Hooks get the hardest listen.

---

## 14. The ending

End at the last real payoff, then follow the channel's ending format (end CTA and closing line, from `workflow.md` and the persona profile). No recap, no wind-down, no "so that's everything." The last useful thing the viewer hears should be a practical next action, never a promise of a future video's topic.
